classdef DifferentialProblem < NumericalMethod
    % Handles ODE solving methods like Euler and Runge-Kutta
    
    methods
        function obj = DifferentialProblem(f)
            obj@NumericalMethod(f);% calls on the parent cnstructor.
        end
        
        function result = solve(obj, method, t0, y0, h, n) % implements ODE solving methods.
            % method: 'euler' or 'rk4'
            switch lower(method)
                case 'euler'
                    result = obj.eulerMethod(t0, y0, h, n);
                case 'rk4'
                    result = obj.rungeKutta4(t0, y0, h, n);
                otherwise
                    error('Unknown method. Use "euler" or "rk4".');
            end
        end
    end
    
    methods (Access = private) % protected within, the user cannot see what is tking place.
        function y = eulerMethod(obj, t0, y0, h, n)
            y = zeros(1, n+1);
            y(1) = y0;
            t = t0;
            for i = 1:n
                y(i+1) = y(i) + h * obj.funct(t, y(i));
                t = t + h;
            end
        end
        
        function y = rungeKutta4(obj, t0, y0, h, n)
            y = zeros(1, n+1);
            y(1) = y0;
            t = t0;
            for i = 1:n
                k1 = obj.funct(t, y(i));
                k2 = obj.funct(t + h/2, y(i) + h*k1/2);
                k3 = obj.funct(t + h/2, y(i) + h*k2/2);
                k4 = obj.funct(t + h, y(i) + h*k3);
                y(i+1) = y(i) + (h/6)*(k1 + 2*k2 + 2*k3 + k4);
                t = t + h;
            end
        end
    end
end
