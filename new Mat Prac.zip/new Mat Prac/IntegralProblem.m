classdef IntegralProblem < NumericalMethod
    % Handles numerical integration methods
    
    methods
        function obj = IntegralProblem(f)
            obj@NumericalMethod(f); % calls on parent constructor
        end
        
        function result = solve(obj, method, a, b, n)
            % method: 'trapezoidal' or 'simpson'
            switch lower(method)
                case 'trapezoidal'
                    result = obj.trapezoidalRule(a, b, n);
                case 'simpson'
                    result = obj.simpsonsRule(a, b, n);
                otherwise
                    error('Unknown method. Use "trapezoidal" or "simpson".');
            end
        end
    end
    
    methods (Access = private)
        function I = trapezoidalRule(obj, a, b, n)
            h = (b - a) / n;
            x = a:h:b;
            y = obj.funct(x);
            I = (h/2) * (y(1) + 2*sum(y(2:end-1)) + y(end));
        end
        
        function I = simpsonsRule(obj, a, b, n)
            if mod(n, 2) ~= 0
                error('n must be even for Simpson''s rule.');
            end
            h = (b - a) / n;
            x = a:h:b;
            y = obj.funct(x);
            I = (h/3) * (y(1) + 4*sum(y(2:2:end-1)) + 2*sum(y(3:2:end-2)) + y(end));
        end
    end
end
