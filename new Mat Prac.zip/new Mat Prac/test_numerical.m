% Test script for Numerical Methods OOP implementation

% Differential problem: dy/dt = y - t^2 + 1
f_diff = @(t, y) y - t.^2 + 1;
diffSolver = DifferentialProblem(f_diff);

y_euler = diffSolver.solve('euler', 0, 0.5, 0.2, 10);
y_rk4   = diffSolver.solve('rk4', 0, 0.5, 0.2, 10);

disp('Euler Method Result:');
disp(y_euler);
disp('Runge-Kutta 4 Result:');
disp(y_rk4);

% Integral problem: ∫(x^2) dx from 0 to 2
f_int = @(x) x.^2;
intSolver = IntegralProblem(f_int);

I_trap = intSolver.solve('trapezoidal', 0, 2, 10);
I_simp = intSolver.solve('simpson', 0, 2, 10);

disp(['Trapezoidal Rule Result: ', num2str(I_trap)]);
disp(['Simpson''s Rule Result: ', num2str(I_simp)]);
