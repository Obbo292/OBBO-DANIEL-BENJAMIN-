classdef (Abstract) NumericalMethod  % Abstract base class for numerical methods
    properties (Access = protected) % protected property, accessible only within this class and subclass.
        funct   % Function handle for the problem
    end
    
    methods
        function obj = NumericalMethod(f) % constructor, sets the problem description.
            if nargin > 0
                if isa(f, 'function_handle') % checking if 'f' is a function hundle
                    obj.funct = f;
                else
                    error('Function must be a valid function handle.');
                end
            end
        end
    end
    
    % Abstract methods to be implemented by subclasses
    methods (Abstract)
        result = solve(obj, varargin)
    end
end
